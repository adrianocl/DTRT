#================================================#
#            LOADING R PACKAGES              #####
#================================================#

library (deSolve)
library (ReacTran)
library(plotly)
library(rstudioapi)

#================================================#
#            SETTING TIME ZONE               #####
#================================================#

Sys.setenv(TZ='Europe/Rome')

#================================================#
#            MODEL FORMULATION               #####
#================================================#
ParamLoad <- function(){
  
  
  #############  FARM PARAMETERS  #################
  Po <- 440*3600        # Portata entrata         [L/h]
  V <- (8*200*0.8)*1000 # Volume Vasca            [L]
  
  #############  FISH PARAMETERS  #################
  k0 <- 9e-4            # Fasting Catabolism at 0�C
  pk <- 0.07
  
  #############  O2 PARAMETERS  ###################
  O   <- 40*60/1000     # Portata Ossigeno        [m3/h]
  R   <- 8.314          # Constant                [J�K-1�mol-1]
  P   <- 101325         # Pressione di iniezzione [Pa]
  Mm  <- 31.998         # Massa molare di O2      [g/mol]
  
  
  #############  Reaeration     ###################  
  
  krear   = 0.046       # Reaeration rate         [h-1]
  

  #############  All parameters  ##################
  
  return (list(Po = Po, V = V, k0 = k0, pk = pk, O = O, R = R, P = P, Mm = Mm, krear = krear))
  
}

  #############  Model           ##################


model <- function (t, y, parms,...) {
 
  ## Upstream boundary condition: compute O2 in Entrance, upstream from the injection of LO2
  
     COUP <- function(t) 
    
  {
     DOin[t*60/dT]

     }
     
  ## Upstream boundary condition: compute the injection of LO2   
     
    S <- function(t) 
    {
      0.9*1000*(Param$Mm*((Param$P*Param$O)/(Param$R*(Tempin[t*60/dT]+273.15))))/Param$Po # [mg/L]
    }
    
  ### Temperature along the distance: assume a linear behaviour
    
    LinearCoefTemp <- function(t)
    {
      Tempin[t*60/dT]
    }
  
    AngularCoefTemp <- function(t)
       {
      (Tempout[t*60/dT]-Tempin[t*60/dT])/TotalLength
    }  
    
    Tmean <- function(t)
  
    {
      (Tempin[t*60/dT] + Tempout[t*60/dT])/2
    }
    

    
  ### Total fish weight per raceway volume  (g/L)
    
    FishWeightperV <- function(t)
      {
      MeanFishWeight[t*60/dT]*TotalNFish[t*60/dT]/Param$V
    }  
    
### Fish oxygen consumption rate, sinusoidal Metabolic rate
    ###k0
    Functionk0 <- function (t)
    {
      Param$k0 + Param$Amp*(cos((2*pi/24)*(t*60/dT) + 2*pi*Param$Phi/24)) 
    }
    
    
    
    ### Differential Equation of DO  
    
    adv <- advection.1D(y, v = v, dx = dx, 
                        C.up = COUP(t)+S(t), ...)
    
    return(list(adv$dC
                + Param$krear*(14.589 - 0.4*(LinearCoefTemp(t) + AngularCoefTemp(t)*(1:n)) 
                               + 0.008*(LinearCoefTemp(t) + AngularCoefTemp(t)*(1:n))^2 
                               - 0.0000661*(LinearCoefTemp(t) + AngularCoefTemp(t)*(1:n))^3-y)
                ##### Respiration, sinusoidal rate
                - 1000*((Functionk0(t)/24)*exp(0.07*Tmean(t)))*FishWeightperV(t)
                ##### Respiration, constant rate
                #                - 1000*((Param$k0/24)*exp(Param$pk*Tmean(t)))*FishWeightperV(t)
    ))
}

#================================================#
#            LOADING FIELD DATA              #####
#================================================#
#Checking the current working directory

setwd(dirname(getActiveDocumentContext()$path))       # Set working directory to source file location
getwd()

UPdata<-readRDS("5min_definitivi_ingresso_2019_07.rds")
DOWNdata<-readRDS("5min_definitivi_uscita_2019_07.rds")


#================================================#
#              LOAD PARAMETERS                ####
#================================================#
Param = ParamLoad()

#================================================#
#            PERIOD DEFINITION               #####
#================================================#
DayStart  <- as.POSIXct("2019/07/03", format = "%Y/%m/%d")
DayStop   <- as.POSIXct("2019/07/11", format = "%Y/%m/%d")
start <- which(DOWNdata$DAYS == DayStart)[1]
stop <- rev(which(DOWNdata$DAYS == DayStop))[1]
UP = UPdata[(start:stop),]
DOWN = DOWNdata[(start:stop),]
dT  <- 5 #[min]
Nhour <- length(UP$DAYS)/(60/dT)  
Ntimesteps <- length(UP$DAYS)   #number of time steps

Param$Amp <- -0.00026
Param$Phi <- 2
Param$k0 <- 0.00088

#================================================#
#       WEIGHT DATA FROM BIOENERGETIC MODEL  #####
#================================================#

#Reading files
CalcWeight=utils::read.csv(paste0("weight.csv"),sep=",",header=TRUE)#Calculated weight
DaysCalcWeight=utils::read.csv(paste0("days.csv"),sep=",",header=TRUE)#Days

#Merging calculated weights and dates  
CalcWeight$X<-DaysCalcWeight$x

#Selecting period
start1 <- which(CalcWeight$X == DayStart)[1]
stop1 <- rev(which(CalcWeight$X == DayStop))[1]
CalcWeight = CalcWeight[(start1:stop1),]
colnames(CalcWeight) <- c("DAYS","CALC_WEIGHT_g") #Renaming columns

#Adjusting to the number of time steps
CalcWeightLong <- CalcWeight[rep(seq_len(nrow(CalcWeight)), each = 24*60/dT), ]

#Replacing with calculated data
UP$LEO_WEIGHT_g <- CalcWeightLong$CALC_WEIGHT_g
DOWN$LEO_WEIGHT_g <- CalcWeightLong$CALC_WEIGHT_g


#####

DOin <- UP$ODO.mg.L
Tempin <- UP$Temp.C
Tempout <- DOWN$Temp.C
DOout <- DOWN$ODO.mg.L
TotalNFish <- DOWN$LEO_NUM
MeanFishWeight <- DOWN$LEO_WEIGHT_g 

#================================================#
#            PARAMETERS                      #####
#================================================#

n           <- 10 #number of boxes 
TotalLength <- 200 #[m]
dx          <- TotalLength/n #[m]
y           <- c(rep(DOin[[1]],n))
v            <- Param$Po/(Param$V/TotalLength) #[m/h]
times        <- seq(from = dT/60, to = Nhour, by = dT/60)




#================================================#
#            DO  SOLUTION                    #####
#================================================#

print(system.time(
  out <- ode.1D(y = y, times = times, func = model, parms = 0, nspec = 1, names = "FunctionY")
))

colnames(out) <- c('time', seq(from = dx, to = TotalLength, by = dx))
Distance <- seq(from = 0, to = TotalLength, by = dx)


TData<-c(UP$TIME)
XData<-c(Distance)
OutData=t(out)
OutData[1,]<-(UP$ODO.mg.L+0.9*1000*(Param$Mm*((Param$P*Param$O)/(Param$R*(UP$Temp.C+273.15))))/Param$Po )
DOData=matrix(data.frame(OutData))

fig <- plot_ly(
  x = XData, 
  y = TData, 
  z = DOData, 
  type = "contour" 
)

fig
