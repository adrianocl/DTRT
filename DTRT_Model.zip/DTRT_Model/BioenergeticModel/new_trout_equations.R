# RAINBOW TROUT BIOENERGETIC INDIVIDUAL GRAOWTH MODEL EQUATIONS
#
#' @param Param vector containing all metabolic parameters
#' @param Temperature water temperature forcing at time t
#' @param G food entering the cage at time t
#' @param Food food characterization (Proteins, Lipids, Carbohydrates)
#' @param weight individual weight at time t
#'
#' @return model output at time t
#'
#' @import matrixStats plotrix rstudioapi
#' 
Trout_ind_equations <- function(Param, Temperature, G, Food, weight
                                ,h
                                ){
  
  # Parameters definition
  ingmax=Param[1]        # [g/d] Maximum ingestion rate
  alpha=Param[2]         # [-] Feeding catabolism coefficient
  betaprot=Param[3]      # [-] Assimilation coefficient for protein
  betalip=Param[4]       # [-] Assimilation coefficient for lipid
  betacarb=Param[5]      # [-] Assimilation coefficient for carbohydrates
  epsprot=Param[6]       # [J/gprot] Energy content of protein
  epslip=Param[7]        # [J/glip] Energy content of lipid
  epscarb=Param[8]       # [J/gcarb] Energy content of carbohydrate
  epsO2=Param[9]         # [J/gO2] Energy consumed by the respiration of 1g of oxygen
  pk=Param[10]           # Unit Modif by AL [1/Celsius degree] Temperature coefficient for the fasting catabolism
  k0=Param[11]           # Unit Modif by AL [1/day] Fasting catabolism at 0 Celsius degree
  m=Param[12]            # [-] Weight exponent for the anabolism
  n=Param[13]            # [-] Weight exponent for the catabolism
  betac=Param[14]        # [-]  Shape coefficient for the H(Tw) function
  Tma=Param[15]          # [Celsius degree] Maximum lethal temperature for Dicentrarchus labrax
  Toa=Param[16]          # [Celsius degree] Optimal temperature for Dicentrarchus labrax
  Taa=Param[17]          # [Celsius degree] Lowest feeding temperature for Dicentrarchus labrax
  a=Param[19]            # [J/gtissue] intercept for somatic energy of fish tissue
  k=Param[20]            # [-] slope coefficient for energy content
  eff=Param[21]          # [-] Food ingestion efficiency
  
  # Food composition definition
  Pcont=Food[1]       # [-] Percentage of proteins in the food
  Lcont=Food[2]       # [-] Percentage of lipids in the food
  Ccont=Food[3]       # [-] Percentage of carbohydrates in the food
  
  # EQUATIONS
  
  # Forcing temperature
  fgT=(((Tma-Temperature)/(Tma-Toa))^(betac*(Tma-Toa)))*exp(betac*(Temperature-Toa)) # Optimum Temperature dependance for ingestion
  frT= exp(pk*Temperature)                                                    # Exponential Temperature dependance for catabolism
  Tfun=cbind(fgT, frT)                                                 # Output with temperature limitation functions
  
  # Ingested mass
  ing=ingmax*(weight^m)#*fgT   # [g/d] Potential ingestion rate
  G=G*eff                     # [g/d] Ingested food (a part of the available food falls through the net)
  
  # Lowest feeding temperature threshold
  if (Temperature<Taa) {
    ing=0
  } else {
    ingvero=ing 
  }
  # Available food limitation
  if (ing>G) {
    ingvero=G           # [g/d] Actual ingestion rate
  }  else {
    ingvero=G           # [g/d] Actual ingestion rate
  }
  # Energy content of somatic tissue [J/g] Source:  Van Poorten (2010)
  #  epstiss=a+(weight*k)
  epstiss=a
  
  # Ingested energy
  diet=(Pcont*epsprot*betaprot+Lcont*epslip*betalip+Ccont*epscarb*betacarb)#* fgT # [J/g] Energy content of the ingested food
  assE=ingvero*diet  # [J/d] Ingested energy
  
  # Compute excretion
  Pexc=(1-betaprot)*Pcont*ingvero  # Excreted proteins [g/d]
  Lexc=(1-betalip)*Lcont*ingvero   # Excreted lipids [g/d]
  Cexc=(1-betacarb)*Ccont*ingvero  # Excreted carbohydrates [g/d]
  exc=cbind(Pexc,Lexc,Cexc)        # Output with excretion values
  
  # Compute waste
  Pwst=((G/eff)-ingvero)*Pcont     # Proteines to waste [g/d]
  Lwst=((G/eff)-ingvero)*Lcont     # Lipids to waste [g/d]
  Cwst=((G/eff)-ingvero)*Ccont     # Carbohydrates to waste [g/d]
  wst=cbind(Pwst,Cwst,Lwst)        # Output with waste values
  
  # Metabolism terms
  anab=assE*(1-alpha)                    # Net anabolism [J/d]
  catab=epsO2*k0*frT*(weight^n)          # Fasting catabolism [J/d]
  metab=cbind(anab,catab)                # Output with metabolic rates
  
  # O2 and NH4 produced
   O2=catab/epsO2          # O2 consumed [g02/d]
  
  # Mass balance
  dw = (anab-catab)/epstiss # weight increment [g/d]
  
  # Biomass
  BM=20000*weight #[g]
  

  #Hourly temperatures
  TempHourCoef=utils::read.csv(paste0(userpath,"/Trout_individual/Inputs/Forcings//Hourly_Water_temperature_Coef.csv"),sep=",",header=FALSE)        # Reading the temperature time series (daily series) data
  TempHourCoef2=TempHourCoef[[1]]
 
  HT <- function(h)  
  {
    return(TempHourCoef2[h])  
  }
  
  HourTemp=cbind(Temperature*HT(1:24))

  # DO Sat
  DOSat=cbind(14.589-0.4*(Temperature*HT(1:24))
            +0.008*(Temperature*HT(1:24))^2
            -0.0000661*(Temperature*HT(1:24))^3)

  #DO in the inlet
  DOin=0.9*DOSat
  
  #Respiration rate
  
  HoursFrom0<- function(h)  
  {
    return(h-1)  
  }
  
  Amp=-0.00026
  Phi=2
  V_L=1280000
  kk0=k0 + Amp*(cos((2*pi/24)*(0:23) + 2*pi*Phi/24))
  fish=1000*((kk0/24)*exp(pk*(Temperature*HT(1:24)))*BM)/V_L

  # Function outputs
  output=list(dw,
              exc,
              wst,
              ing,
              ingvero,
              Tfun,
              metab,
              O2
              ,BM
              ,HourTemp
              ,DOSat
              ,DOin
              ,fish
  )
  return(output) # Trout_ind_equations output
}
