#================================================#
#            SETTING TIME ZONE               #####
#================================================#

Sys.setenv(TZ='Europe/Rome')

#==========================================#
#             INIT WORKSPACE            ####
#==========================================#
rm(list = ls())

library(rstudioapi)

userpath <- setwd(dirname(getActiveDocumentContext()$path))       # Set working directory to source file location
getwd()

#==========================================#
#             LOAD MODULES              ####
#==========================================#

source("trout_main.R")
source("trout_dataloader.R")
source("trout_pre.R")
source("trout_RKsolver.R")
source("new_trout_equations.R")
source("trout_post.R")

#==========================================#
#             GENERATE RESULTS          ####
#==========================================#

forcings <- Trout_ind_dataloader(userpath)
OUT <- Trout_ind_main()
