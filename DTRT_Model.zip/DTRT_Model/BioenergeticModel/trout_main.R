#' rainbow trout bioenergetic individual growth model
#'
#' Solves the bioenergetic balance for rainbow trout
#'
#' @param userpath the path where forcing are located
#' @param forcings a list containing the time series in the odd positions and realted forcings in the even positions. Forcings returned are: Water temperature [Celsius degrees] and feeding rate [g/individual x d]
#' @return A list containing model outputs: weight, excreted quantities and quantities to waste, actual and potential ingestion, temperature limitation functions and metabolic rates
#' @export
#'
#' @import matrixStats plotrix rstudioapi
#'

Trout_ind_main<-function(userpath,forcings){
  
  rm(list=ls())        # Clean workspace
  
  cat('Rainbow trout bioenergetic individual based growth model\n')
  cat(" \n")
  
  # Run the preprocessor for the first time to print to screen parameters and forcing selected
  out_pre<-Trout_ind_pre(userpath,forcings)

  # Extract preprocessor outputs
  Param=out_pre[[1]]
  Tint=out_pre[[2]]
  Gint=out_pre[[3]]
  Food=out_pre[[4]]
  IC=out_pre[[5]]
  times=out_pre[[6]]
  Dates=out_pre[[7]]

  # Solves ODE
  out_RKsolver<-Trout_ind_RKsolver(Param, Tint, Gint, Food, IC, times
                                   ,h
                                   )

  # Post-process data
  out_post<-Trout_ind_post(userpath, out_RKsolver, times, Dates
  #                        ,CS
                            )
  # 
  cat(" ")
  cat("End")
  
  return(list(out_RKsolver))
  
}
